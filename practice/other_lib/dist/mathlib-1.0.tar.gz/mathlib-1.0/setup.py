#!/usr/bin/python3

from distutils.core import setup

setup(name="mathlib",
      version="1.0",
      py_modules=['mathlib'],
     )



