#!/usr/bin/python3

def echoprint():
   print("SUCCESS")

def add(a,b):
    return a+b

if __name__ == "__main__":
    print("You are treating me like main program")
else:
    print("Hello i am loaded")
